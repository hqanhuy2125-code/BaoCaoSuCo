package vhu.edu.gdchinhsua.manager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.card.MaterialCardView;

import vhu.edu.gdchinhsua.R;

public class ManagerProfileFragment extends Fragment {

    private MaterialCardView cardIncidents, cardApproval, cardFacility, cardFinance, cardRoster, cardSystem;

    public static ManagerProfileFragment newInstance() {
        return new ManagerProfileFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_manager_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupListeners();
    }

    private void initViews(View view) {
        cardIncidents = view.findViewById(R.id.card_incident_management);
        cardApproval = view.findViewById(R.id.card_resident_approval);
        cardFacility = view.findViewById(R.id.card_facility_oversight);
        cardFinance = view.findViewById(R.id.card_financial_reports);
        cardRoster = view.findViewById(R.id.card_staff_rosters);
        cardSystem = view.findViewById(R.id.card_system_configurations);
    }

    private void setupListeners() {
        if (cardIncidents != null) {
            cardIncidents.setOnClickListener(v -> {
                if (getActivity() instanceof ManagerMainActivity) {
                    ((ManagerMainActivity) getActivity()).selectTab(0);
                }
            });
        }

        if (cardApproval != null) {
            cardApproval.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Duyệt Tài Khoản Cư Dân Mới", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardFacility != null) {
            cardFacility.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Quản Lý Tiện Ích Tòa Nhà (Gym, BBQ)", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardFinance != null) {
            cardFinance.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Báo Cáo Tài Chính & Doanh Thu", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardRoster != null) {
            cardRoster.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Phân Công Lịch Trực Kỹ Thuật Viên", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardSystem != null) {
            cardSystem.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Cấu Hình Hệ Thống & Phân Quyền", Toast.LENGTH_SHORT).show()
            );
        }
    }
}