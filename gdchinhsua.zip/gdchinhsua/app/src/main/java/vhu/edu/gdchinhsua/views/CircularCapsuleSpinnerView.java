package vhu.edu.gdchinhsua.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CircularCapsuleSpinnerView extends View {

    private Paint fillPaintPink;
    private Paint fillPaintWhite;
    private Paint borderPaint;

    private float currentRotation = 0f;
    private ValueAnimator rotationAnimator;

    private final RectF capsuleRect = new RectF();

    public CircularCapsuleSpinnerView(Context context) {
        super(context);
        init();
    }

    public CircularCapsuleSpinnerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CircularCapsuleSpinnerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Inner Fill Pink (#F05D78)
        fillPaintPink = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaintPink.setStyle(Paint.Style.FILL);
        fillPaintPink.setColor(Color.parseColor("#F05D78"));

        // Inner Fill White (#FFFFFF)
        fillPaintWhite = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaintWhite.setStyle(Paint.Style.FILL);
        fillPaintWhite.setColor(Color.WHITE);

        // Crisp Black Border (#000000)
        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(Color.BLACK);
        borderPaint.setStrokeWidth(6f); // Black border stroke width

        startRotationAnimation();
    }

    private void startRotationAnimation() {
        rotationAnimator = ValueAnimator.ofFloat(0f, 360f);
        rotationAnimator.setDuration(3000); // Smooth continuous 360 degree rotation
        rotationAnimator.setInterpolator(new LinearInterpolator());
        rotationAnimator.setRepeatCount(ValueAnimator.INFINITE);
        rotationAnimator.addUpdateListener(animation -> {
            currentRotation = (float) animation.getAnimatedValue();
            invalidate();
        });
        rotationAnimator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (rotationAnimator != null) {
            rotationAnimator.cancel();
        }
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        if (width == 0 || height == 0) return;

        float centerX = width / 2f;
        float centerY = height / 2f;

        // Radius from center to center of capsules
        float size = Math.min(width, height);
        float radiusOffset = size * 0.28f;
        float capsuleWidth = size * 0.12f;
        float capsuleHeight = size * 0.28f;
        float cornerRadius = capsuleWidth / 2f;

        canvas.save();
        // Rotate around center point
        canvas.rotate(currentRotation, centerX, centerY);

        // 6 capsule bars at 60 degree intervals (0, 60, 120, 180, 240, 300)
        for (int i = 0; i < 6; i++) {
            canvas.save();

            // Rotate canvas for each bar position
            float angle = i * 60f;
            canvas.rotate(angle, centerX, centerY);

            // Positioning capsule bar radially outward
            float left = centerX - capsuleWidth / 2f;
            float top = centerY - radiusOffset - capsuleHeight / 2f;
            float right = left + capsuleWidth;
            float bottom = top + capsuleHeight;

            capsuleRect.set(left, top, right, bottom);

            // Alternating Pink (#F05D78) and White (#FFFFFF) fill
            Paint fillPaint = (i % 2 == 0) ? fillPaintPink : fillPaintWhite;

            // 1. Draw solid color fill inside rounded capsule
            canvas.drawRoundRect(capsuleRect, cornerRadius, cornerRadius, fillPaint);

            // 2. Draw crisp black border around rounded capsule
            canvas.drawRoundRect(capsuleRect, cornerRadius, cornerRadius, borderPaint);

            canvas.restore();
        }

        canvas.restore();
    }
}