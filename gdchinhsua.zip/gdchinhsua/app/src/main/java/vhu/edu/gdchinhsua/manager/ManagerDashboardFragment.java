package vhu.edu.gdchinhsua.manager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.card.MaterialCardView;

import java.util.List;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.data.IncidentRepository;
import vhu.edu.gdchinhsua.models.Incident;

public class ManagerDashboardFragment extends Fragment {

    private TextView tvStatTotal, tvStatPending, tvStatProcessing, tvStatOverdue, tvStatCompleted;
    private TextView tvSystemHealthMsg;
    private MaterialCardView cardTotal, cardPending, cardProcessing, cardOverdue, cardCompleted;

    public static ManagerDashboardFragment newInstance() {
        return new ManagerDashboardFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_manager_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupListeners();
        loadStats();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadStats();
    }

    private void initViews(View view) {
        tvStatTotal = view.findViewById(R.id.tv_stat_total);
        tvStatPending = view.findViewById(R.id.tv_stat_pending);
        tvStatProcessing = view.findViewById(R.id.tv_stat_processing);
        tvStatOverdue = view.findViewById(R.id.tv_stat_overdue);
        tvStatCompleted = view.findViewById(R.id.tv_stat_completed);
        tvSystemHealthMsg = view.findViewById(R.id.tv_system_health_msg);

        cardTotal = view.findViewById(R.id.card_stat_total);
        cardPending = view.findViewById(R.id.card_stat_pending);
        cardProcessing = view.findViewById(R.id.card_stat_processing);
        cardOverdue = view.findViewById(R.id.card_stat_overdue);
        cardCompleted = view.findViewById(R.id.card_stat_completed);
    }

    private void setupListeners() {
        View.OnClickListener openAllIncidentsListener = v -> {
            if (getActivity() instanceof ManagerMainActivity) {
                ((ManagerMainActivity) getActivity()).selectTab(0);
            }
        };

        View.OnClickListener openOverdueIncidentsListener = v -> {
            if (getActivity() instanceof ManagerMainActivity) {
                ((ManagerMainActivity) getActivity()).selectTab(2);
            }
        };

        if (cardTotal != null) cardTotal.setOnClickListener(openAllIncidentsListener);
        if (cardPending != null) cardPending.setOnClickListener(openAllIncidentsListener);
        if (cardProcessing != null) cardProcessing.setOnClickListener(openAllIncidentsListener);
        if (cardCompleted != null) cardCompleted.setOnClickListener(openAllIncidentsListener);
        if (cardOverdue != null) cardOverdue.setOnClickListener(openOverdueIncidentsListener);
    }

    private void loadStats() {
        List<Incident> all = IncidentRepository.getInstance().getAllIncidents();

        int total = all.size();
        int pending = 0;
        int processing = 0;
        int overdue = 0;
        int completed = 0;

        for (Incident inc : all) {
            if (inc.isOverdue()) {
                overdue++;
            }
            switch (inc.getStatus()) {
                case PENDING:
                    pending++;
                    break;
                case PROCESSING:
                    processing++;
                    break;
                case COMPLETED:
                    completed++;
                    break;
            }
        }

        tvStatTotal.setText(String.valueOf(total));
        tvStatPending.setText(String.valueOf(pending));
        tvStatProcessing.setText(String.valueOf(processing));
        tvStatOverdue.setText(String.valueOf(overdue));
        tvStatCompleted.setText(String.valueOf(completed));

        if (overdue > 0) {
            tvSystemHealthMsg.setText("⚠️ Cảnh báo: Có " + overdue + " sự cố đang quá hạn (>24h). Vui lòng phân công kỹ thuật viên xử lý gấp!");
            tvSystemHealthMsg.setTextColor(0xFFEE5253);
        } else {
            tvSystemHealthMsg.setText("✅ Hệ thống căn hộ đang hoạt động ổn định. Tất cả sự cố đều trong tiến độ xử lý.");
            tvSystemHealthMsg.setTextColor(0xFF1DD1A1);
        }
    }
}