package vhu.edu.gdchinhsua.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.models.Incident;

public class IncidentAdapter extends RecyclerView.Adapter<IncidentAdapter.IncidentViewHolder> {

    public interface OnIncidentClickListener {
        void onIncidentClick(Incident incident);
    }

    private List<Incident> incidentList;
    private final OnIncidentClickListener listener;

    public IncidentAdapter(List<Incident> incidentList, OnIncidentClickListener listener) {
        this.incidentList = incidentList != null ? incidentList : new ArrayList<>();
        this.listener = listener;
    }

    public void updateData(List<Incident> newList) {
        this.incidentList = newList != null ? newList : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public IncidentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_incident, parent, false);
        return new IncidentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull IncidentViewHolder holder, int position) {
        Incident incident = incidentList.get(position);
        holder.bind(incident, listener);

        // Subtle item entrance animation
        holder.itemView.startAnimation(AnimationUtils.loadAnimation(holder.itemView.getContext(), android.R.anim.fade_in));
    }

    @Override
    public int getItemCount() {
        return incidentList.size();
    }

    static class IncidentViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvPriorityBadge;
        private final TextView tvStatusBadge;
        private final TextView tvOverdueBadge;
        private final TextView tvTitle;
        private final TextView tvLocation;
        private final TextView tvTimestamp;
        private final TextView tvHandler;

        public IncidentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPriorityBadge = itemView.findViewById(R.id.tv_priority_badge);
            tvStatusBadge = itemView.findViewById(R.id.tv_status_badge);
            tvOverdueBadge = itemView.findViewById(R.id.tv_overdue_badge);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvLocation = itemView.findViewById(R.id.tv_location);
            tvTimestamp = itemView.findViewById(R.id.tv_timestamp);
            tvHandler = itemView.findViewById(R.id.tv_handler);
        }

        public void bind(Incident incident, OnIncidentClickListener listener) {
            tvTitle.setText(incident.getTitle());
            tvLocation.setText(incident.getLocation());
            tvTimestamp.setText(incident.getFormattedDate());
            tvHandler.setText("Kỹ thuật: " + incident.getHandlerName());

            // Priority Badge
            tvPriorityBadge.setText(incident.getPriorityLabel());
            switch (incident.getPriority()) {
                case URGENT:
                    tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_urgent);
                    tvPriorityBadge.setTextColor(0xFFC62828);
                    break;
                case LOW:
                    tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_processing);
                    tvPriorityBadge.setTextColor(0xFFB78103);
                    break;
                case NORMAL:
                default:
                    tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_processing);
                    tvPriorityBadge.setTextColor(0xFFB78103);
                    break;
            }

            // EXACT 3-STATUS COLOR SYSTEM
            // RED = NOT PROCESSED / PENDING
            // YELLOW = PROCESSING
            // GREEN = COMPLETED
            tvStatusBadge.setText(incident.getStatusLabel());
            switch (incident.getStatus()) {
                case PROCESSING:
                    tvStatusBadge.setBackgroundResource(R.drawable.bg_badge_processing);
                    tvStatusBadge.setTextColor(0xFFB78103); // Dark Amber text on Amber background
                    break;
                case COMPLETED:
                    tvStatusBadge.setBackgroundResource(R.drawable.bg_badge_completed);
                    tvStatusBadge.setTextColor(0xFF1B5E20); // Dark Green text on Green background
                    break;
                case PENDING:
                default:
                    tvStatusBadge.setBackgroundResource(R.drawable.bg_badge_pending);
                    tvStatusBadge.setTextColor(0xFFC62828); // Dark Red text on Red background
                    break;
            }

            // Overdue Badge Indicator (Red)
            if (incident.isOverdue()) {
                tvOverdueBadge.setVisibility(View.VISIBLE);
                tvOverdueBadge.setBackgroundResource(R.drawable.bg_badge_overdue);
                tvOverdueBadge.setTextColor(0xFFC62828);
            } else {
                tvOverdueBadge.setVisibility(View.GONE);
            }

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onIncidentClick(incident);
                }
            });
        }
    }
}