package vhu.edu.gdchinhsua.resident;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.card.MaterialCardView;

import vhu.edu.gdchinhsua.R;

public class ResidentExploreFragment extends Fragment {

    private static final String ARG_RESIDENT_EMAIL = "resident_email";
    private String residentEmail;

    private MaterialCardView cardBill, cardMaint, cardNotice, cardSettings;

    public static ResidentExploreFragment newInstance(String residentEmail) {
        ResidentExploreFragment fragment = new ResidentExploreFragment();
        Bundle args = new Bundle();
        args.putString(ARG_RESIDENT_EMAIL, residentEmail);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            residentEmail = getArguments().getString(ARG_RESIDENT_EMAIL);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_resident_explore, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupListeners();
    }

    private void initViews(View view) {
        cardBill = view.findViewById(R.id.card_bill_payments);
        cardMaint = view.findViewById(R.id.card_maintenance_requests);
        cardNotice = view.findViewById(R.id.card_community_announcements);
        cardSettings = view.findViewById(R.id.card_account_settings);
    }

    private void setupListeners() {
        if (cardBill != null) {
            cardBill.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Thanh Toán Hóa Đơn & Phí Quản Lý Căn Hộ", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardMaint != null) {
            cardMaint.setOnClickListener(v -> {
                if (getActivity() instanceof ResidentMainActivity) {
                    ((ResidentMainActivity) getActivity()).selectTab(2); // Navigate to B01 Create Incident Form
                }
            });
        }

        if (cardNotice != null) {
            cardNotice.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Thông Báo Cư Dân & Ban Quản Lý Tòa Nhà", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardSettings != null) {
            cardSettings.setOnClickListener(v -> {
                if (getActivity() instanceof ResidentMainActivity) {
                    ((ResidentMainActivity) getActivity()).selectTab(4); // Navigate to Profile / Settings
                }
            });
        }
    }
}