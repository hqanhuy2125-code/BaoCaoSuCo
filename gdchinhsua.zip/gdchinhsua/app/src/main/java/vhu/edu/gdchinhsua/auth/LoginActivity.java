package vhu.edu.gdchinhsua.auth;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.data.ThemeManager;

public class LoginActivity extends AppCompatActivity {

    private ImageView ivGearAnim;
    private ImageButton btnThemeToggle;
    private TextView tvFormTitle;
    private TextInputLayout tilName, tilRoom, tilEmail, tilPassword;
    private TextInputEditText etName, etRoom, etEmail, etPassword;
    private MaterialButton btnAction;
    private ProgressBar pbLoginLoading;
    private TextView tvSwitchMode;
    private MaterialButton btnGoogleAuth;

    private boolean isRegisterMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        startGearAnimation();
        setupListeners();
    }

    private void initViews() {
        ivGearAnim = findViewById(R.id.iv_gear_anim);
        btnThemeToggle = findViewById(R.id.btn_theme_toggle);
        tvFormTitle = findViewById(R.id.tv_form_title);

        tilName = findViewById(R.id.til_name);
        tilRoom = findViewById(R.id.til_room);
        tilEmail = findViewById(R.id.til_email);
        tilPassword = findViewById(R.id.til_password);

        etName = findViewById(R.id.et_name);
        etRoom = findViewById(R.id.et_room);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);

        btnAction = findViewById(R.id.btn_action);
        pbLoginLoading = findViewById(R.id.pb_login_loading);
        tvSwitchMode = findViewById(R.id.tv_switch_mode);
        btnGoogleAuth = findViewById(R.id.btn_google_auth);

        // Fill default demo email for quick testing
        etEmail.setText("resident@gmail.com");
        etPassword.setText("123456");
    }

    private void startGearAnimation() {
        RotateAnimation rotate = new RotateAnimation(
                0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        rotate.setDuration(12000);
        rotate.setRepeatCount(Animation.INFINITE);
        ivGearAnim.startAnimation(rotate);
    }

    private void setupListeners() {
        // Theme Toggle Listener
        btnThemeToggle.setOnClickListener(v -> {
            ThemeManager.toggleTheme(this);
            recreate();
        });

        // Real-time Email Regex Validation
        etEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = s.toString().trim();
                if (!input.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(input).matches()) {
                    tilEmail.setError(getString(R.string.invalid_email));
                } else {
                    tilEmail.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Mode switch (Login vs Register)
        tvSwitchMode.setOnClickListener(v -> toggleRegisterMode());

        // Login / Register Submit
        btnAction.setOnClickListener(v -> attemptAuthentication());

        // Google Authentication simulation
        btnGoogleAuth.setOnClickListener(v -> {
            Toast.makeText(this, "Đang kết nối Google Authentication...", Toast.LENGTH_SHORT).show();
            performSuccessLogin("google.user@gmail.com");
        });
    }

    private void toggleRegisterMode() {
        isRegisterMode = !isRegisterMode;
        if (isRegisterMode) {
            tvFormTitle.setText(R.string.btn_register);
            tilName.setVisibility(View.VISIBLE);
            tilRoom.setVisibility(View.VISIBLE);
            btnAction.setText(R.string.btn_register);
            tvSwitchMode.setText(R.string.switch_to_login);
            btnGoogleAuth.setText(R.string.btn_google_register);
        } else {
            tvFormTitle.setText(R.string.login_title);
            tilName.setVisibility(View.GONE);
            tilRoom.setVisibility(View.GONE);
            btnAction.setText(R.string.btn_login);
            tvSwitchMode.setText(R.string.switch_to_register);
            btnGoogleAuth.setText(R.string.btn_google_signin);
        }
    }

    private void attemptAuthentication() {
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError(getString(R.string.invalid_email));
            return;
        }

        if (password.length() < 6) {
            tilPassword.setError(getString(R.string.invalid_password));
            return;
        }

        if (isRegisterMode) {
            String name = etName.getText() != null ? etName.getText().toString().trim() : "";
            String room = etRoom.getText() != null ? etRoom.getText().toString().trim() : "";
            if (name.isEmpty()) {
                tilName.setError("Vui lòng nhập họ tên!");
                return;
            }
            if (room.isEmpty()) {
                tilRoom.setError("Vui lòng nhập số phòng/căn hộ!");
                return;
            }
        }

        // Show Loading State inside Button
        btnAction.setText("");
        btnAction.setEnabled(false);
        pbLoginLoading.setVisibility(View.VISIBLE);

        // Simulate network call then launch Custom Loading Activity Screen
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            pbLoginLoading.setVisibility(View.GONE);
            btnAction.setEnabled(true);
            btnAction.setText(isRegisterMode ? R.string.btn_register : R.string.btn_login);

            performSuccessLogin(email);
        }, 800);
    }

    private void performSuccessLogin(String email) {
        // Launch Custom Canvas Loading Animation Screen
        Intent intent = new Intent(this, LoadingActivity.class);
        intent.putExtra("user_email", email);
        startActivity(intent);
        finish();
    }
}