package vhu.edu.gdchinhsua.manager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.adapters.IncidentAdapter;
import vhu.edu.gdchinhsua.data.IncidentRepository;
import vhu.edu.gdchinhsua.models.Incident;

public class ManagerListFragment extends Fragment implements IncidentAdapter.OnIncidentClickListener {

    private static final String ARG_SHOW_OVERDUE_ONLY = "show_overdue_only";
    private boolean showOverdueOnly = false;

    private EditText etManagerSearch;
    private ChipGroup chipGroupManagerFilter;
    private RecyclerView rvManagerIncidents;
    private IncidentAdapter adapter;
    private LinearLayout layoutLoading, layoutEmpty, layoutError;
    private MaterialButton btnManagerRetry;

    private List<Incident> allIncidents = new ArrayList<>();
    private String currentSearchQuery = "";
    private int currentFilterId = R.id.chip_mgr_all;

    public static ManagerListFragment newInstance(boolean showOverdueOnly) {
        ManagerListFragment fragment = new ManagerListFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_SHOW_OVERDUE_ONLY, showOverdueOnly);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            showOverdueOnly = getArguments().getBoolean(ARG_SHOW_OVERDUE_ONLY, false);
            if (showOverdueOnly) {
                currentFilterId = R.id.chip_mgr_overdue;
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_manager_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadData();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void initViews(View view) {
        etManagerSearch = view.findViewById(R.id.et_manager_search);
        chipGroupManagerFilter = view.findViewById(R.id.chip_group_manager_filter);
        rvManagerIncidents = view.findViewById(R.id.rv_manager_incidents);
        layoutLoading = view.findViewById(R.id.layout_manager_loading);
        layoutEmpty = view.findViewById(R.id.layout_manager_empty);
        layoutError = view.findViewById(R.id.layout_manager_error);
        btnManagerRetry = view.findViewById(R.id.btn_manager_retry);

        if (showOverdueOnly) {
            chipGroupManagerFilter.check(R.id.chip_mgr_overdue);
        }
    }

    private void setupRecyclerView() {
        adapter = new IncidentAdapter(new ArrayList<>(), this);
        rvManagerIncidents.setLayoutManager(new LinearLayoutManager(getContext()));
        rvManagerIncidents.setAdapter(adapter);
    }

    private void setupListeners() {
        btnManagerRetry.setOnClickListener(v -> loadData());

        etManagerSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentSearchQuery = s.toString().trim().toLowerCase();
                filterAndDisplay();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        chipGroupManagerFilter.setOnCheckedChangeListener((group, checkedId) -> {
            currentFilterId = checkedId;
            filterAndDisplay();
        });
    }

    private void loadData() {
        showLoading();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                allIncidents = IncidentRepository.getInstance().getAllIncidents();
                filterAndDisplay();
            } catch (Exception e) {
                showError();
            }
        }, 500);
    }

    private void filterAndDisplay() {
        List<Incident> filteredList = new ArrayList<>();

        for (Incident inc : allIncidents) {
            boolean matchesSearch = currentSearchQuery.isEmpty()
                    || inc.getTitle().toLowerCase().contains(currentSearchQuery)
                    || inc.getLocation().toLowerCase().contains(currentSearchQuery)
                    || inc.getResidentName().toLowerCase().contains(currentSearchQuery);

            if (!matchesSearch) continue;

            if (currentFilterId == R.id.chip_mgr_overdue && !inc.isOverdue()) {
                continue;
            } else if (currentFilterId == R.id.chip_mgr_pending && inc.getStatus() != Incident.Status.PENDING) {
                continue;
            } else if (currentFilterId == R.id.chip_mgr_processing && inc.getStatus() != Incident.Status.PROCESSING) {
                continue;
            } else if (currentFilterId == R.id.chip_mgr_completed && inc.getStatus() != Incident.Status.COMPLETED) {
                continue;
            }

            filteredList.add(inc);
        }

        if (filteredList.isEmpty()) {
            showEmpty();
        } else {
            showContent();
            adapter.updateData(filteredList);
        }
    }

    private void showLoading() {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        layoutError.setVisibility(View.GONE);
        rvManagerIncidents.setVisibility(View.GONE);
    }

    private void showEmpty() {
        layoutLoading.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.VISIBLE);
        layoutError.setVisibility(View.GONE);
        rvManagerIncidents.setVisibility(View.GONE);
    }

    private void showError() {
        layoutLoading.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        layoutError.setVisibility(View.VISIBLE);
        rvManagerIncidents.setVisibility(View.GONE);
    }

    private void showContent() {
        layoutLoading.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        layoutError.setVisibility(View.GONE);
        rvManagerIncidents.setVisibility(View.VISIBLE);
    }

    @Override
    public void onIncidentClick(Incident incident) {
        Intent intent = new Intent(getContext(), ManagerDetailActivity.class);
        intent.putExtra("incident_id", incident.getId());
        startActivity(intent);
    }
}