package vhu.edu.gdchinhsua.resident;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.data.IncidentRepository;
import vhu.edu.gdchinhsua.data.ThemeManager;
import vhu.edu.gdchinhsua.models.Incident;

public class ResidentDetailActivity extends AppCompatActivity {

    private ImageButton btnBack;
    private TextView tvPriority, tvStatus, tvTitle, tvLocation, tvCreatedAt, tvDesc, tvHandler;
    private ImageView ivStep1, ivStep2, ivStep3;
    private TextView tvStep1, tvStep2, tvStep3;
    private MaterialCardView cardResidentConfirm;
    private MaterialButton btnConfirmDone, btnConfirmNotDone;
    private TextView tvFeedbackStatus;

    private Incident currentIncident;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resident_detail);

        String incidentId = getIntent().getStringExtra("incident_id");
        if (incidentId != null) {
            currentIncident = IncidentRepository.getInstance().getIncidentById(incidentId);
        }

        initViews();
        bindData();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btn_back);
        tvPriority = findViewById(R.id.tv_detail_priority);
        tvStatus = findViewById(R.id.tv_detail_status);
        tvTitle = findViewById(R.id.tv_detail_title);
        tvLocation = findViewById(R.id.tv_detail_location);
        tvCreatedAt = findViewById(R.id.tv_detail_created_at);
        tvDesc = findViewById(R.id.tv_detail_desc);
        tvHandler = findViewById(R.id.tv_detail_handler);

        ivStep1 = findViewById(R.id.iv_step1);
        ivStep2 = findViewById(R.id.iv_step2);
        ivStep3 = findViewById(R.id.iv_step3);

        tvStep1 = findViewById(R.id.tv_step1);
        tvStep2 = findViewById(R.id.tv_step2);
        tvStep3 = findViewById(R.id.tv_step3);

        cardResidentConfirm = findViewById(R.id.card_resident_confirm);
        btnConfirmDone = findViewById(R.id.btn_confirm_done);
        btnConfirmNotDone = findViewById(R.id.btn_confirm_not_done);
        tvFeedbackStatus = findViewById(R.id.tv_feedback_status);
    }

    private void bindData() {
        if (currentIncident == null) {
            Toast.makeText(this, "Không tìm thấy dữ liệu sự cố!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvTitle.setText(currentIncident.getTitle());
        tvLocation.setText("Vị trí: " + currentIncident.getLocation());
        tvCreatedAt.setText("Thời gian gửi: " + currentIncident.getFormattedDate());
        tvDesc.setText(currentIncident.getDescription());
        tvHandler.setText("Kỹ thuật viên phụ trách: " + currentIncident.getHandlerName());

        // Priority Badge
        tvPriority.setText(currentIncident.getPriorityLabel());
        switch (currentIncident.getPriority()) {
            case URGENT:
                tvPriority.setBackgroundResource(R.drawable.bg_badge_urgent);
                tvPriority.setTextColor(0xFFC62828);
                break;
            case LOW:
                tvPriority.setBackgroundResource(R.drawable.bg_badge_processing);
                tvPriority.setTextColor(0xFFB78103);
                break;
            case NORMAL:
            default:
                tvPriority.setBackgroundResource(R.drawable.bg_badge_processing);
                tvPriority.setTextColor(0xFFB78103);
                break;
        }

        // Status Badge & Timeline (3-Status Color System)
        tvStatus.setText(currentIncident.getStatusLabel());
        switch (currentIncident.getStatus()) {
            case PROCESSING:
                tvStatus.setBackgroundResource(R.drawable.bg_badge_processing);
                tvStatus.setTextColor(0xFFB78103); // Yellow/Amber
                break;
            case COMPLETED:
                tvStatus.setBackgroundResource(R.drawable.bg_badge_completed);
                tvStatus.setTextColor(0xFF1B5E20); // Green
                break;
            case PENDING:
            default:
                tvStatus.setBackgroundResource(R.drawable.bg_badge_pending);
                tvStatus.setTextColor(0xFFC62828); // Red
                break;
        }

        updateProgressTimeline(currentIncident.getStatus());
        updateFeedbackCardUI();
    }

    private void updateProgressTimeline(Incident.Status status) {
        int colorRed = 0xFFE53935;
        int colorYellow = 0xFFF4B400;
        int colorGreen = 0xFF2E7D32;
        int colorInactive = 0xFFA4B0BE;

        // Step 1: Submitted (Pending / Red)
        ivStep1.setImageResource(R.drawable.ic_check_circle);
        ivStep1.setColorFilter(colorRed);
        tvStep1.setTextColor(0xFF1A202C);

        if (status == Incident.Status.PROCESSING) {
            ivStep2.setImageResource(R.drawable.ic_check_circle);
            ivStep2.setColorFilter(colorYellow); // Step 2: Processing (Yellow)
            tvStep2.setTextColor(0xFF1A202C);

            ivStep3.setImageResource(R.drawable.ic_clock);
            ivStep3.setColorFilter(colorInactive);
            tvStep3.setTextColor(colorInactive);
        } else if (status == Incident.Status.COMPLETED) {
            ivStep1.setColorFilter(colorGreen);
            ivStep2.setImageResource(R.drawable.ic_check_circle);
            ivStep2.setColorFilter(colorGreen);
            tvStep2.setTextColor(0xFF1A202C);

            ivStep3.setImageResource(R.drawable.ic_check_circle);
            ivStep3.setColorFilter(colorGreen); // Step 3: Completed (Green)
            tvStep3.setTextColor(0xFF1A202C);
        } else {
            // Pending
            ivStep2.setImageResource(R.drawable.ic_clock);
            ivStep2.setColorFilter(colorInactive);
            tvStep2.setTextColor(colorInactive);

            ivStep3.setImageResource(R.drawable.ic_clock);
            ivStep3.setColorFilter(colorInactive);
            tvStep3.setTextColor(colorInactive);
        }
    }

    private void updateFeedbackCardUI() {
        if (currentIncident == null) return;

        String feedback = currentIncident.getResidentFeedback();
        if ("DONE".equals(feedback)) {
            tvFeedbackStatus.setVisibility(View.VISIBLE);
            tvFeedbackStatus.setText("✓ Bạn đã xác nhận sự cố ĐÃ ĐƯỢC XỬ LÝ HOÀN TOÀN.");
            tvFeedbackStatus.setTextColor(0xFF2E7D32);
        } else if ("NOT_DONE".equals(feedback)) {
            tvFeedbackStatus.setVisibility(View.VISIBLE);
            tvFeedbackStatus.setText("⚠️ Bạn đã phản hồi sự cố CHƯA XONG và cần kiểm tra lại.");
            tvFeedbackStatus.setTextColor(0xFFE53935);
        } else {
            tvFeedbackStatus.setVisibility(View.GONE);
        }
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnConfirmDone.setOnClickListener(v -> {
            if (currentIncident != null) {
                IncidentRepository.getInstance().updateFeedback(currentIncident.getId(), "DONE");
                currentIncident.setResidentFeedback("DONE");
                updateFeedbackCardUI();
                Toast.makeText(this, R.string.feedback_submitted, Toast.LENGTH_SHORT).show();
            }
        });

        btnConfirmNotDone.setOnClickListener(v -> {
            if (currentIncident != null) {
                IncidentRepository.getInstance().updateFeedback(currentIncident.getId(), "NOT_DONE");
                currentIncident.setResidentFeedback("NOT_DONE");
                updateFeedbackCardUI();
                Toast.makeText(this, R.string.feedback_submitted, Toast.LENGTH_SHORT).show();
            }
        });
    }
}