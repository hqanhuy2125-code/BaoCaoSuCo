package vhu.edu.gdchinhsua.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomCapsuleProgressBar extends View {

    private Paint trackPaintLightBlue;
    private Paint progressPaintPink;
    private Paint borderPaintBlack;

    private float progress = 0f; // 0.0 to 1.0 (0% to 100%)
    private ValueAnimator progressAnimator;

    private final RectF totalBounds = new RectF();
    private final RectF progressBounds = new RectF();
    private final Path clipPath = new Path();

    public interface OnProgressListener {
        void onProgressUpdated(int percent);
        void onProgressCompleted();
    }

    private OnProgressListener listener;

    public CustomCapsuleProgressBar(Context context) {
        super(context);
        init();
    }

    public CustomCapsuleProgressBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomCapsuleProgressBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Remaining Track Light Blue (#A8E5F8)
        trackPaintLightBlue = new Paint(Paint.ANTI_ALIAS_FLAG);
        trackPaintLightBlue.setStyle(Paint.Style.FILL);
        trackPaintLightBlue.setColor(Color.parseColor("#A8E5F8"));

        // Completed Progress Pink (#F05D78)
        progressPaintPink = new Paint(Paint.ANTI_ALIAS_FLAG);
        progressPaintPink.setStyle(Paint.Style.FILL);
        progressPaintPink.setColor(Color.parseColor("#F05D78"));

        // Black Border (#000000)
        borderPaintBlack = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaintBlack.setStyle(Paint.Style.STROKE);
        borderPaintBlack.setColor(Color.BLACK);
        borderPaintBlack.setStrokeWidth(6f); // Crisp black border
    }

    public void setOnProgressListener(OnProgressListener listener) {
        this.listener = listener;
    }

    public void startProgressAnimation(long durationMs) {
        if (progressAnimator != null && progressAnimator.isRunning()) {
            progressAnimator.cancel();
        }

        progressAnimator = ValueAnimator.ofFloat(0f, 1f);
        progressAnimator.setDuration(durationMs);
        progressAnimator.setInterpolator(new DecelerateInterpolator());
        progressAnimator.addUpdateListener(animation -> {
            progress = (float) animation.getAnimatedValue();
            int percent = (int) (progress * 100);
            if (listener != null) {
                listener.onProgressUpdated(percent);
            }
            invalidate();
            if (progress >= 1.0f && listener != null) {
                listener.onProgressCompleted();
            }
        });
        progressAnimator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (progressAnimator != null) {
            progressAnimator.cancel();
        }
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        float strokeHalf = 3f;
        totalBounds.set(strokeHalf, strokeHalf, width - strokeHalf, height - strokeHalf);
        float cornerRadius = height / 2f; // Fully rounded capsule ends

        // Clip region to rounded capsule total bounds
        clipPath.reset();
        clipPath.addRoundRect(totalBounds, cornerRadius, cornerRadius, Path.Direction.CW);

        canvas.save();
        canvas.clipPath(clipPath);

        // 1. Draw entire background unfilled track with Light Blue (#A8E5F8)
        canvas.drawRoundRect(totalBounds, cornerRadius, cornerRadius, trackPaintLightBlue);

        // 2. Draw completed progress portion with Pink (#F05D78)
        float progressWidth = totalBounds.width() * progress;
        if (progressWidth > 0) {
            progressBounds.set(totalBounds.left, totalBounds.top, totalBounds.left + progressWidth, totalBounds.bottom);
            canvas.drawRect(progressBounds, progressPaintPink);
        }

        canvas.restore();

        // 3. Draw outer Black Border (#000000)
        canvas.drawRoundRect(totalBounds, cornerRadius, cornerRadius, borderPaintBlack);
    }
}