package vhu.edu.gdchinhsua.data;

import java.util.ArrayList;
import java.util.List;

import vhu.edu.gdchinhsua.models.Incident;

public class IncidentRepository {

    private static IncidentRepository instance;
    private final List<Incident> incidentsList;

    private IncidentRepository() {
        incidentsList = new ArrayList<>();
        seedMockData();
    }

    public static synchronized IncidentRepository getInstance() {
        if (instance == null) {
            instance = new IncidentRepository();
        }
        return instance;
    }

    private void seedMockData() {
        long now = System.currentTimeMillis();
        long hourMs = 60 * 60 * 1000L;
        long dayMs = 24 * 60 * 60 * 1000L;

        // 1. Urgent incident (Overdue > 28 hours)
        Incident i1 = new Incident(
                "INC-1001",
                "Chập điện khu vực nhà bếp",
                "Cầu chì bống nhiên bị sập và có mùi khét nhẹ ở ổ cắm tủ lạnh. Cần thợ kiểm tra gấp!",
                "Phòng 302 - Tầng 3",
                Incident.Priority.URGENT,
                Incident.Status.PENDING,
                "Nguyễn Văn An",
                "resident@gmail.com",
                "Chưa phân công",
                now - (28 * hourMs)
        );

        // 2. Urgent incident (Processing)
        Incident i2 = new Incident(
                "INC-1002",
                "Hỏng vòi nước bồn rửa mặt",
                "Vòi nước rò rỉ liên tục gây ngập sàn nhà vệ sinh.",
                "Phòng 205 - Tầng 2",
                Incident.Priority.URGENT,
                Incident.Status.PROCESSING,
                "Lê Thị Bình",
                "lethibinh@gmail.com",
                "Anh Nam - Kỹ thuật Nước",
                now - (5 * hourMs)
        );

        // 3. Normal incident (Completed)
        Incident i3 = new Incident(
                "INC-1003",
                "Thang máy B bị giật khi di chuyển",
                "Khi đi từ tầng 1 lên tầng 5 thang máy có tiếng kêu lạ và rung nhẹ.",
                "Thang máy Tòa B",
                Incident.Priority.NORMAL,
                Incident.Status.COMPLETED,
                "Trần Hoàng Cường",
                "resident@gmail.com",
                "Ban Quản Lý Tòa Nhà",
                now - (2 * dayMs)
        );
        i3.setResidentFeedback("DONE");

        // 4. Low incident (Pending)
        Incident i4 = new Incident(
                "INC-1004",
                "Đèn hành lang bị cháy bóng",
                "Bóng đèn cao áp ở cuối hành lang tầng 4 bị hỏng tối om.",
                "Hành lang Tầng 4",
                Incident.Priority.LOW,
                Incident.Status.PENDING,
                "Phạm Đức Dung",
                "dungpham@gmail.com",
                "Chưa phân công",
                now - (12 * hourMs)
        );

        // 5. Normal incident (Pending)
        Incident i5 = new Incident(
                "INC-1005",
                "Khóa cửa vân tay hết pin",
                "Khóa cửa chính phát tiếng kêu báo pin yếu liên tục.",
                "Phòng 401 - Tầng 4",
                Incident.Priority.NORMAL,
                Incident.Status.PENDING,
                "Vũ Thị Dung",
                "resident@gmail.com",
                "Chưa phân công",
                now - (2 * hourMs)
        );

        incidentsList.add(i1);
        incidentsList.add(i2);
        incidentsList.add(i3);
        incidentsList.add(i4);
        incidentsList.add(i5);
    }

    public synchronized List<Incident> getAllIncidents() {
        return new ArrayList<>(incidentsList);
    }

    public synchronized List<Incident> getIncidentsByResident(String residentEmail) {
        List<Incident> result = new ArrayList<>();
        for (Incident inc : incidentsList) {
            if (inc.getResidentEmail() != null && inc.getResidentEmail().equalsIgnoreCase(residentEmail)) {
                result.add(inc);
            }
        }
        return result;
    }

    public synchronized void addIncident(Incident incident) {
        if (incident.getId() == null || incident.getId().isEmpty()) {
            incident.setId("INC-" + (1000 + incidentsList.size() + 1));
        }
        incidentsList.add(0, incident); // latest first
    }

    public synchronized Incident getIncidentById(String id) {
        for (Incident inc : incidentsList) {
            if (inc.getId().equals(id)) {
                return inc;
            }
        }
        return null;
    }

    public synchronized boolean updateStatus(String id, Incident.Status newStatus, String handlerName) {
        Incident incident = getIncidentById(id);
        if (incident != null) {
            incident.setStatus(newStatus);
            if (handlerName != null && !handlerName.isEmpty()) {
                incident.setHandlerName(handlerName);
            }
            return true;
        }
        return false;
    }

    public synchronized boolean updateFeedback(String id, String feedback) {
        Incident incident = getIncidentById(id);
        if (incident != null) {
            incident.setResidentFeedback(feedback);
            return true;
        }
        return false;
    }

    public synchronized List<Incident> getOverdueIncidents() {
        List<Incident> result = new ArrayList<>();
        for (Incident inc : incidentsList) {
            if (inc.isOverdue()) {
                result.add(inc);
            }
        }
        return result;
    }
}