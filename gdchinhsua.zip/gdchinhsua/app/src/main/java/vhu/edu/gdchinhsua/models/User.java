package vhu.edu.gdchinhsua.models;

import java.io.Serializable;

public class User implements Serializable {

    public enum Role {
        RESIDENT,
        MANAGER
    }

    private String email;
    private String name;
    private String roomNumber;
    private Role role;

    public User(String email, String name, String roomNumber, Role role) {
        this.email = email;
        this.name = name;
        this.roomNumber = roomNumber;
        this.role = role;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
}