package vhu.edu.gdchinhsua.resident;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.auth.LoginActivity;

public class ResidentProfileFragment extends Fragment {

    private static final String ARG_RESIDENT_EMAIL = "resident_email";
    private String residentEmail;

    private TextView tvName, tvRoleUnit, tvEmail;
    private MaterialCardView cardPersonal, cardSecurity, cardNotif;
    private MaterialButton btnLogout;

    public static ResidentProfileFragment newInstance(String residentEmail) {
        ResidentProfileFragment fragment = new ResidentProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_RESIDENT_EMAIL, residentEmail);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            residentEmail = getArguments().getString(ARG_RESIDENT_EMAIL);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_resident_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        bindProfileData();
        setupListeners();
    }

    private void initViews(View view) {
        tvName = view.findViewById(R.id.tv_profile_full_name);
        tvRoleUnit = view.findViewById(R.id.tv_profile_role_unit);
        tvEmail = view.findViewById(R.id.tv_profile_email);

        cardPersonal = view.findViewById(R.id.card_personal_info);
        cardSecurity = view.findViewById(R.id.card_security_settings);
        cardNotif = view.findViewById(R.id.card_app_notifications);
        btnLogout = view.findViewById(R.id.btn_profile_logout);
    }

    private void bindProfileData() {
        if (residentEmail != null && !residentEmail.isEmpty()) {
            if (tvEmail != null) tvEmail.setText(residentEmail);
            String namePart = residentEmail.split("@")[0];
            if (tvName != null) tvName.setText("Cư dân: " + namePart);
        }
        if (tvRoleUnit != null) {
            tvRoleUnit.setText("Cư Dân - Block P - Phòng 302");
        }
    }

    private void setupListeners() {
        if (cardPersonal != null) {
            cardPersonal.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Cập Nhật Thông Tin Cá Nhân", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardSecurity != null) {
            cardSecurity.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Đổi Mật Khẩu & Bảo Mật Tài Khoản", Toast.LENGTH_SHORT).show()
            );
        }

        if (cardNotif != null) {
            cardNotif.setOnClickListener(v ->
                    Toast.makeText(getContext(), "Tính năng: Cài Đặt Thông Báo Ứng Dụng", Toast.LENGTH_SHORT).show()
            );
        }

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                if (getActivity() != null) {
                    Toast.makeText(getContext(), "Đã đăng xuất tài khoản!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    getActivity().finish();
                }
            });
        }
    }
}