package vhu.edu.gdchinhsua.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.data.ThemeManager;
import vhu.edu.gdchinhsua.manager.ManagerMainActivity;
import vhu.edu.gdchinhsua.resident.ResidentMainActivity;
import vhu.edu.gdchinhsua.views.CustomCapsuleProgressBar;

public class LoadingActivity extends AppCompatActivity {

    private CustomCapsuleProgressBar capsuleProgressBar;
    private TextView tvProgressPercent;

    private String userEmail;
    private boolean isManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        userEmail = getIntent().getStringExtra("user_email");
        if (userEmail == null) userEmail = "resident@gmail.com";

        // Dynamic Role Routing Rule:
        // Exactly "quanly@gmail.com" -> Manager, otherwise -> Resident
        isManager = "quanly@gmail.com".equalsIgnoreCase(userEmail.trim());

        initViews();
        startProgress();
    }

    private void initViews() {
        capsuleProgressBar = findViewById(R.id.capsule_progress_bar);
        tvProgressPercent = findViewById(R.id.tv_progress_percent);
    }

    private void startProgress() {
        capsuleProgressBar.setOnProgressListener(new CustomCapsuleProgressBar.OnProgressListener() {
            @Override
            public void onProgressUpdated(int percent) {
                tvProgressPercent.setText(percent + "%");
            }

            @Override
            public void onProgressCompleted() {
                navigateToDestination();
            }
        });

        // 2.2 seconds smooth progress animation
        capsuleProgressBar.startProgressAnimation(2200);
    }

    private void navigateToDestination() {
        Intent intent;
        if (isManager) {
            intent = new Intent(LoadingActivity.this, ManagerMainActivity.class);
            intent.putExtra("user_email", userEmail);
            intent.putExtra("user_name", "Quản Lý Tòa Nhà");
        } else {
            intent = new Intent(LoadingActivity.this, ResidentMainActivity.class);
            intent.putExtra("user_email", userEmail);
            intent.putExtra("user_name", "Cư Dân (" + userEmail.split("@")[0] + ")");
        }
        startActivity(intent);
        finish();
    }
}