package vhu.edu.gdchinhsua.manager;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.auth.LoginActivity;
import vhu.edu.gdchinhsua.data.ThemeManager;

public class ManagerMainActivity extends AppCompatActivity {

    private TextView welcomeText;
    private TextView titleText;
    private ImageButton logoutButton;
    private ImageButton themeToggleButton;

    private TextView tvHeaderResidentName;
    private TextView tvHeaderResidentUnit;
    private TextView tvHeaderResidentEmail;

    // Custom Bottom Navigation Bar Views (Style 01 - Minimal Clean Floating Bar)
    private View navBarRootContainer;
    private LinearLayout navItemHome, navItemExplore, navItemProjects, navItemSaved, navItemProfile;
    private ImageView ivNavHome, ivNavExplore, ivNavProjects, ivNavSaved, ivNavProfile;
    private TextView tvNavHome, tvNavExplore, tvNavProjects, tvNavSaved, tvNavProfile;
    private View dotNavHome, dotNavExplore, dotNavProjects, dotNavSaved, dotNavProfile;

    private String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manager_main);

        userName = getIntent().getStringExtra("user_name");
        if (userName == null) userName = "Quản Lý Tòa Nhà";

        initViews();
        setupWindowInsets();
        setupEvents();

        // Default open Manager List fragment (Home Tab)
        selectTab(0);
    }

    private void initViews() {
        welcomeText = findViewById(R.id.welcome_text);
        titleText = findViewById(R.id.title_text);
        logoutButton = findViewById(R.id.logout_button);
        themeToggleButton = findViewById(R.id.theme_toggle_button);

        tvHeaderResidentName = findViewById(R.id.tv_header_resident_name);
        tvHeaderResidentUnit = findViewById(R.id.tv_header_resident_unit);
        tvHeaderResidentEmail = findViewById(R.id.tv_header_resident_email);

        if (welcomeText != null) {
            welcomeText.setText(getString(R.string.manager_welcome) + " " + userName);
        }
        if (titleText != null) {
            titleText.setText(R.string.manager_title);
        }

        if (tvHeaderResidentName != null) {
            tvHeaderResidentName.setText("Quản lý: " + userName);
        }
        if (tvHeaderResidentUnit != null) {
            tvHeaderResidentUnit.setText("Chức vụ: Trưởng Ban Quản Lý (Block P)");
        }
        if (tvHeaderResidentEmail != null) {
            tvHeaderResidentEmail.setText("quanly@gmail.com");
        }

        // Custom Bottom Navigation Bar Views
        navBarRootContainer = findViewById(R.id.nav_bar_root_container);
        navItemHome = findViewById(R.id.nav_item_home);
        navItemExplore = findViewById(R.id.nav_item_explore);
        navItemProjects = findViewById(R.id.nav_item_projects);
        navItemSaved = findViewById(R.id.nav_item_saved);
        navItemProfile = findViewById(R.id.nav_item_profile);

        ivNavHome = findViewById(R.id.iv_nav_home);
        ivNavExplore = findViewById(R.id.iv_nav_explore);
        ivNavProjects = findViewById(R.id.iv_nav_projects);
        ivNavSaved = findViewById(R.id.iv_nav_saved);
        ivNavProfile = findViewById(R.id.iv_nav_profile);

        tvNavHome = findViewById(R.id.tv_nav_home);
        tvNavExplore = findViewById(R.id.tv_nav_explore);
        tvNavProjects = findViewById(R.id.tv_nav_projects);
        tvNavSaved = findViewById(R.id.tv_nav_saved);
        tvNavProfile = findViewById(R.id.tv_nav_profile);

        dotNavHome = findViewById(R.id.dot_nav_home);
        dotNavExplore = findViewById(R.id.dot_nav_explore);
        dotNavProjects = findViewById(R.id.dot_nav_projects);
        dotNavSaved = findViewById(R.id.dot_nav_saved);
        dotNavProfile = findViewById(R.id.dot_nav_profile);
    }

    private void setupWindowInsets() {
        if (navBarRootContainer != null) {
            ViewCompat.setOnApplyWindowInsetsListener(navBarRootContainer, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(
                        v.getPaddingLeft(),
                        v.getPaddingTop(),
                        v.getPaddingRight(),
                        systemBars.bottom + 12
                );
                return insets;
            });
        }
    }

    private void setupEvents() {
        if (logoutButton != null) {
            logoutButton.setOnClickListener(v -> {
                Toast.makeText(this, "Đã đăng xuất tài khoản Quản Lý!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            });
        }

        if (themeToggleButton != null) {
            themeToggleButton.setOnClickListener(v -> {
                ThemeManager.toggleTheme(this);
                recreate();
            });
        }

        // Bottom Navigation Bar Click Listeners
        if (navItemHome != null) navItemHome.setOnClickListener(v -> selectTab(0));
        if (navItemExplore != null) navItemExplore.setOnClickListener(v -> selectTab(1));
        if (navItemProjects != null) navItemProjects.setOnClickListener(v -> selectTab(2));
        if (navItemSaved != null) navItemSaved.setOnClickListener(v -> selectTab(3));
        if (navItemProfile != null) navItemProfile.setOnClickListener(v -> selectTab(4));
    }

    public void selectTab(int index) {
        int primaryColor = ContextCompat.getColor(this, R.color.pink_primary_dark);
        boolean isDark = ThemeManager.isDarkMode(this);
        int inactiveColor = isDark ? Color.parseColor("#A4B0BE") : Color.parseColor("#2D3436");

        // Reset all tabs to inactive
        resetTabUI(navItemHome, ivNavHome, tvNavHome, dotNavHome, inactiveColor);
        resetTabUI(navItemExplore, ivNavExplore, tvNavExplore, dotNavExplore, inactiveColor);
        resetTabUI(navItemProjects, ivNavProjects, tvNavProjects, dotNavProjects, inactiveColor);
        resetTabUI(navItemSaved, ivNavSaved, tvNavSaved, dotNavSaved, inactiveColor);
        resetTabUI(navItemProfile, ivNavProfile, tvNavProfile, dotNavProfile, inactiveColor);

        switch (index) {
            case 0: // Trang chủ -> All Manager Incidents B03
                setTabActiveUI(navItemHome, ivNavHome, tvNavHome, dotNavHome, primaryColor);
                loadFragment(ManagerListFragment.newInstance(false), true);
                break;
            case 1: // Khám phá -> Manager Building Analytics & Overview Stats Hub
                setTabActiveUI(navItemExplore, ivNavExplore, tvNavExplore, dotNavExplore, primaryColor);
                loadFragment(ManagerDashboardFragment.newInstance(), true);
                break;
            case 2: // Dự án -> Overdue Incidents (>24h)
                setTabActiveUI(navItemProjects, ivNavProjects, tvNavProjects, dotNavProjects, primaryColor);
                loadFragment(ManagerListFragment.newInstance(true), true);
                break;
            case 3: // Đã lưu -> Manager Financial & Revenue Stats
                setTabActiveUI(navItemSaved, ivNavSaved, tvNavSaved, dotNavSaved, primaryColor);
                loadFragment(ManagerDashboardFragment.newInstance(), true);
                break;
            case 4: // Cá nhân -> Manager Profile Screen
                setTabActiveUI(navItemProfile, ivNavProfile, tvNavProfile, dotNavProfile, primaryColor);
                loadFragment(ManagerProfileFragment.newInstance(), true);
                break;
        }
    }

    private void resetTabUI(LinearLayout container, ImageView iv, TextView tv, View dot, int color) {
        if (container != null) {
            container.setBackgroundResource(android.R.color.transparent);
        }
        if (iv != null) iv.setColorFilter(color);
        if (tv != null) {
            tv.setTextColor(color);
            tv.setTypeface(null, Typeface.NORMAL);
        }
        if (dot != null) dot.setVisibility(View.GONE);
    }

    private void setTabActiveUI(LinearLayout container, ImageView iv, TextView tv, View dot, int color) {
        if (container != null) {
            container.setBackgroundResource(R.drawable.bg_nav_pill_active);
        }
        if (iv != null) iv.setColorFilter(color);
        if (tv != null) {
            tv.setTextColor(color);
            tv.setTypeface(null, Typeface.BOLD);
        }
        if (dot != null) dot.setVisibility(View.VISIBLE);
    }

    private void loadFragment(Fragment fragment, boolean animate) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        if (animate) {
            ft.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
        }
        ft.replace(R.id.fragment_container, fragment);
        ft.commit();
    }
}