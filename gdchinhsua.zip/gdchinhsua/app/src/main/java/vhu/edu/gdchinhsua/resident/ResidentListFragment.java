package vhu.edu.gdchinhsua.resident;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.adapters.IncidentAdapter;
import vhu.edu.gdchinhsua.data.IncidentRepository;
import vhu.edu.gdchinhsua.models.Incident;

public class ResidentListFragment extends Fragment implements IncidentAdapter.OnIncidentClickListener {

    private static final String ARG_RESIDENT_EMAIL = "resident_email";
    private String residentEmail;

    private EditText etSearch;
    private ChipGroup chipGroupFilter;
    private RecyclerView rvIncidents;
    private IncidentAdapter adapter;
    private LinearLayout layoutLoading, layoutEmpty, layoutError;
    private MaterialButton btnEmptyCreate, btnRetry;

    private List<Incident> allResidentIncidents = new ArrayList<>();
    private String currentSearchQuery = "";
    private int currentFilterId = R.id.chip_all;

    public static ResidentListFragment newInstance(String residentEmail) {
        ResidentListFragment fragment = new ResidentListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_RESIDENT_EMAIL, residentEmail);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            residentEmail = getArguments().getString(ARG_RESIDENT_EMAIL);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_resident_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadIncidentsData();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh data when returning from Detail screen
        loadIncidentsData();
    }

    private void initViews(View view) {
        etSearch = view.findViewById(R.id.et_search);
        chipGroupFilter = view.findViewById(R.id.chip_group_filter);
        rvIncidents = view.findViewById(R.id.rv_incidents);
        layoutLoading = view.findViewById(R.id.layout_loading);
        layoutEmpty = view.findViewById(R.id.layout_empty);
        layoutError = view.findViewById(R.id.layout_error);
        btnEmptyCreate = view.findViewById(R.id.btn_empty_create);
        btnRetry = view.findViewById(R.id.btn_retry);
    }

    private void setupRecyclerView() {
        adapter = new IncidentAdapter(new ArrayList<>(), this);
        rvIncidents.setLayoutManager(new LinearLayoutManager(getContext()));
        rvIncidents.setAdapter(adapter);
    }

    private void setupListeners() {
        // Empty state button click
        btnEmptyCreate.setOnClickListener(v -> {
            if (getActivity() instanceof ResidentMainActivity) {
                ((ResidentMainActivity) getActivity()).navigateToCreateIncident();
            }
        });

        // Retry click
        btnRetry.setOnClickListener(v -> loadIncidentsData());

        // Search text watcher
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentSearchQuery = s.toString().trim().toLowerCase();
                filterAndDisplay();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Filter chips
        chipGroupFilter.setOnCheckedChangeListener((group, checkedId) -> {
            currentFilterId = checkedId;
            filterAndDisplay();
        });
    }

    private void loadIncidentsData() {
        showLoadingState();

        // Simulate async data load
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                if (residentEmail != null && !residentEmail.isEmpty()) {
                    allResidentIncidents = IncidentRepository.getInstance().getIncidentsByResident(residentEmail);
                } else {
                    allResidentIncidents = IncidentRepository.getInstance().getAllIncidents();
                }

                // If demo empty test, fallback to all incidents
                if (allResidentIncidents.isEmpty()) {
                    allResidentIncidents = IncidentRepository.getInstance().getAllIncidents();
                }

                filterAndDisplay();
            } catch (Exception e) {
                showErrorState();
            }
        }, 600);
    }

    private void filterAndDisplay() {
        List<Incident> filteredList = new ArrayList<>();

        for (Incident inc : allResidentIncidents) {
            // Search filter
            boolean matchesSearch = currentSearchQuery.isEmpty()
                    || inc.getTitle().toLowerCase().contains(currentSearchQuery)
                    || inc.getLocation().toLowerCase().contains(currentSearchQuery)
                    || inc.getDescription().toLowerCase().contains(currentSearchQuery);

            if (!matchesSearch) continue;

            // Chip filter
            if (currentFilterId == R.id.chip_pending && inc.getStatus() != Incident.Status.PENDING) {
                continue;
            } else if (currentFilterId == R.id.chip_processing && inc.getStatus() != Incident.Status.PROCESSING) {
                continue;
            } else if (currentFilterId == R.id.chip_completed && inc.getStatus() != Incident.Status.COMPLETED) {
                continue;
            }

            filteredList.add(inc);
        }

        if (filteredList.isEmpty()) {
            showEmptyState();
        } else {
            showContentState();
            adapter.updateData(filteredList);
        }
    }

    private void showLoadingState() {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        layoutError.setVisibility(View.GONE);
        rvIncidents.setVisibility(View.GONE);
    }

    private void showEmptyState() {
        layoutLoading.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.VISIBLE);
        layoutError.setVisibility(View.GONE);
        rvIncidents.setVisibility(View.GONE);
    }

    private void showErrorState() {
        layoutLoading.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        layoutError.setVisibility(View.VISIBLE);
        rvIncidents.setVisibility(View.GONE);
    }

    private void showContentState() {
        layoutLoading.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        layoutError.setVisibility(View.GONE);
        rvIncidents.setVisibility(View.VISIBLE);
    }

    @Override
    public void onIncidentClick(Incident incident) {
        Intent intent = new Intent(getContext(), ResidentDetailActivity.class);
        intent.putExtra("incident_id", incident.getId());
        startActivity(intent);
    }
}