package vhu.edu.gdchinhsua.models;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Incident implements Serializable {

    public enum Priority {
        URGENT,   // Khẩn cấp
        NORMAL,   // Bình thường
        LOW       // Thấp
    }

    public enum Status {
        PENDING,     // Chờ tiếp nhận
        PROCESSING,  // Đang xử lý
        COMPLETED    // Đã hoàn thành
    }

    private String id;
    private String title;
    private String description;
    private String location; // e.g. "Phòng 302 - Nhà bếp"
    private Priority priority;
    private Status status;
    private String residentName;
    private String residentEmail;
    private String handlerName; // Kỹ thuật viên phụ trách
    private long createdAtTimestamp;
    private boolean isOverdue; // Incident pending > 24 hours
    private String residentFeedback; // "DONE", "NOT_DONE", or empty

    public Incident() {
        this.createdAtTimestamp = System.currentTimeMillis();
        this.priority = Priority.NORMAL;
        this.status = Status.PENDING;
        this.residentFeedback = "";
        this.handlerName = "Chưa phân công";
    }

    public Incident(String id, String title, String description, String location,
                    Priority priority, Status status, String residentName,
                    String residentEmail, String handlerName, long createdAtTimestamp) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.location = location;
        this.priority = priority;
        this.status = status;
        this.residentName = residentName;
        this.residentEmail = residentEmail;
        this.handlerName = handlerName;
        this.createdAtTimestamp = createdAtTimestamp;
        this.residentFeedback = "";
        checkOverdue();
    }

    public void checkOverdue() {
        // Overdue if status is PENDING and created more than 24h ago
        long now = System.currentTimeMillis();
        long twentyFourHoursMs = 24 * 60 * 60 * 1000L;
        this.isOverdue = (this.status == Status.PENDING) && ((now - this.createdAtTimestamp) > twentyFourHoursMs);
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) {
        this.status = status;
        checkOverdue();
    }

    public String getResidentName() { return residentName; }
    public void setResidentName(String residentName) { this.residentName = residentName; }

    public String getResidentEmail() { return residentEmail; }
    public void setResidentEmail(String residentEmail) { this.residentEmail = residentEmail; }

    public String getHandlerName() { return handlerName; }
    public void setHandlerName(String handlerName) { this.handlerName = handlerName; }

    public long getCreatedAtTimestamp() { return createdAtTimestamp; }
    public void setCreatedAtTimestamp(long createdAtTimestamp) {
        this.createdAtTimestamp = createdAtTimestamp;
        checkOverdue();
    }

    public boolean isOverdue() {
        checkOverdue();
        return isOverdue;
    }

    public void setOverdue(boolean overdue) { isOverdue = overdue; }

    public String getResidentFeedback() { return residentFeedback; }
    public void setResidentFeedback(String residentFeedback) { this.residentFeedback = residentFeedback; }

    public String getFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm - dd/MM/yyyy", Locale.getDefault());
        return sdf.format(new Date(createdAtTimestamp));
    }

    public String getPriorityLabel() {
        switch (priority) {
            case URGENT: return "Khẩn cấp";
            case LOW: return "Thấp";
            case NORMAL:
            default: return "Bình thường";
        }
    }

    public String getStatusLabel() {
        switch (status) {
            case PROCESSING: return "Đang xử lý";
            case COMPLETED: return "Đã hoàn thành";
            case PENDING:
            default: return "Chờ tiếp nhận";
        }
    }
}