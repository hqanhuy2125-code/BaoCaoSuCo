package vhu.edu.gdchinhsua.manager;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.data.IncidentRepository;
import vhu.edu.gdchinhsua.data.ThemeManager;
import vhu.edu.gdchinhsua.models.Incident;

public class ManagerDetailActivity extends AppCompatActivity {

    private ImageButton btnBack;
    private TextView tvPriority, tvStatus, tvTitle, tvLocation, tvResident, tvCreatedAt, tvDesc;
    private Spinner spinnerTechnician;
    private MaterialButton btnStartProcessing, btnComplete;

    private Incident currentIncident;
    private final String[] technicians = {
            "Anh Nam - Kỹ thuật Điện",
            "Anh Hùng - Kỹ thuật Nước",
            "Anh Tuấn - Bảo trì Tòa nhà",
            "Ban Quản Lý Tòa Nhà"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_detail);

        String incidentId = getIntent().getStringExtra("incident_id");
        if (incidentId != null) {
            currentIncident = IncidentRepository.getInstance().getIncidentById(incidentId);
        }

        initViews();
        bindData();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btn_manager_back);
        tvPriority = findViewById(R.id.tv_mgr_detail_priority);
        tvStatus = findViewById(R.id.tv_mgr_detail_status);
        tvTitle = findViewById(R.id.tv_mgr_detail_title);
        tvLocation = findViewById(R.id.tv_mgr_detail_location);
        tvResident = findViewById(R.id.tv_mgr_detail_resident);
        tvCreatedAt = findViewById(R.id.tv_mgr_detail_created_at);
        tvDesc = findViewById(R.id.tv_mgr_detail_desc);

        spinnerTechnician = findViewById(R.id.spinner_technician);
        btnStartProcessing = findViewById(R.id.btn_mgr_start_processing);
        btnComplete = findViewById(R.id.btn_mgr_complete);

        // Populate Technician Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                technicians
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTechnician.setAdapter(adapter);
    }

    private void bindData() {
        if (currentIncident == null) {
            Toast.makeText(this, "Không tìm thấy thông tin sự cố!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvTitle.setText(currentIncident.getTitle());
        tvLocation.setText("Vị trí: " + currentIncident.getLocation());
        tvResident.setText("Người báo: " + currentIncident.getResidentName() + " (" + currentIncident.getResidentEmail() + ")");
        tvCreatedAt.setText("Thời gian báo: " + currentIncident.getFormattedDate());
        tvDesc.setText(currentIncident.getDescription());

        // Priority Badge
        tvPriority.setText(currentIncident.getPriorityLabel());
        switch (currentIncident.getPriority()) {
            case URGENT:
                tvPriority.setBackgroundResource(R.drawable.bg_badge_urgent);
                tvPriority.setTextColor(0xFFC62828);
                break;
            case LOW:
                tvPriority.setBackgroundResource(R.drawable.bg_badge_processing);
                tvPriority.setTextColor(0xFFB78103);
                break;
            case NORMAL:
            default:
                tvPriority.setBackgroundResource(R.drawable.bg_badge_processing);
                tvPriority.setTextColor(0xFFB78103);
                break;
        }

        // Status Badge
        updateStatusUI();
    }

    private void updateStatusUI() {
        // EXACT 3-STATUS COLOR SYSTEM
        // RED = NOT PROCESSED
        // YELLOW = PROCESSING
        // GREEN = COMPLETED
        tvStatus.setText(currentIncident.getStatusLabel());
        switch (currentIncident.getStatus()) {
            case PROCESSING:
                tvStatus.setBackgroundResource(R.drawable.bg_badge_processing);
                tvStatus.setTextColor(0xFFB78103); // Yellow/Amber text
                btnStartProcessing.setEnabled(false);
                btnComplete.setEnabled(true);
                break;
            case COMPLETED:
                tvStatus.setBackgroundResource(R.drawable.bg_badge_completed);
                tvStatus.setTextColor(0xFF1B5E20); // Green text
                btnStartProcessing.setEnabled(false);
                btnComplete.setEnabled(false);
                break;
            case PENDING:
            default:
                tvStatus.setBackgroundResource(R.drawable.bg_badge_pending);
                tvStatus.setTextColor(0xFFC62828); // Red text
                btnStartProcessing.setEnabled(true);
                btnComplete.setEnabled(true);
                break;
        }
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        // Start processing button (B04)
        btnStartProcessing.setOnClickListener(v -> {
            String chosenTech = (String) spinnerTechnician.getSelectedItem();
            boolean success = IncidentRepository.getInstance().updateStatus(
                    currentIncident.getId(),
                    Incident.Status.PROCESSING,
                    chosenTech
            );

            if (success) {
                currentIncident.setStatus(Incident.Status.PROCESSING);
                currentIncident.setHandlerName(chosenTech);
                updateStatusUI();
                Toast.makeText(this, "Đã chuyển trạng thái sự cố sang ĐANG XỬ LÝ và phân công " + chosenTech, Toast.LENGTH_LONG).show();
            }
        });

        // Complete button (B04)
        btnComplete.setOnClickListener(v -> {
            String chosenTech = (String) spinnerTechnician.getSelectedItem();
            boolean success = IncidentRepository.getInstance().updateStatus(
                    currentIncident.getId(),
                    Incident.Status.COMPLETED,
                    chosenTech
            );

            if (success) {
                currentIncident.setStatus(Incident.Status.COMPLETED);
                currentIncident.setHandlerName(chosenTech);
                updateStatusUI();
                Toast.makeText(this, "Sự cố đã được đánh dấu HOÀN THÀNH!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}