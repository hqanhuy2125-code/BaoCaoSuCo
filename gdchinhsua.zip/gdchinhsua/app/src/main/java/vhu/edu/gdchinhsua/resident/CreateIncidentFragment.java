package vhu.edu.gdchinhsua.resident;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import vhu.edu.gdchinhsua.R;
import vhu.edu.gdchinhsua.data.IncidentRepository;
import vhu.edu.gdchinhsua.models.Incident;

public class CreateIncidentFragment extends Fragment {

    private static final String ARG_RESIDENT_EMAIL = "resident_email";

    private String residentEmail;

    private TextInputLayout tilTitle, tilLocation, tilDesc;
    private TextInputEditText etTitle, etLocation, etDesc;
    private RadioGroup rgPriority;
    private RadioButton rbUrgent, rbNormal, rbLow;
    private MaterialButton btnSubmit;
    private ProgressBar pbSubmitLoading;

    public static CreateIncidentFragment newInstance(String residentEmail) {
        CreateIncidentFragment fragment = new CreateIncidentFragment();
        Bundle args = new Bundle();
        args.putString(ARG_RESIDENT_EMAIL, residentEmail);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            residentEmail = getArguments().getString(ARG_RESIDENT_EMAIL);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_create_incident, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupListeners();
    }

    private void initViews(View view) {
        tilTitle = view.findViewById(R.id.til_incident_title);
        tilLocation = view.findViewById(R.id.til_incident_location);
        tilDesc = view.findViewById(R.id.til_incident_desc);

        etTitle = view.findViewById(R.id.et_incident_title);
        etLocation = view.findViewById(R.id.et_incident_location);
        etDesc = view.findViewById(R.id.et_incident_desc);

        rgPriority = view.findViewById(R.id.rg_priority);
        rbUrgent = view.findViewById(R.id.rb_priority_urgent);
        rbNormal = view.findViewById(R.id.rb_priority_normal);
        rbLow = view.findViewById(R.id.rb_priority_low);

        btnSubmit = view.findViewById(R.id.btn_submit_incident);
        pbSubmitLoading = view.findViewById(R.id.pb_submit_loading);

        // Fill room default if available
        if (etLocation != null) {
            etLocation.setText("Phòng 302 - Khu C");
        }
    }

    private void setupListeners() {
        btnSubmit.setOnClickListener(v -> submitForm());
    }

    private void submitForm() {
        String title = etTitle.getText() != null ? etTitle.getText().toString().trim() : "";
        String location = etLocation.getText() != null ? etLocation.getText().toString().trim() : "";
        String desc = etDesc.getText() != null ? etDesc.getText().toString().trim() : "";

        if (title.isEmpty()) {
            tilTitle.setError("Vui lòng nhập tiêu đề sự cố!");
            return;
        } else {
            tilTitle.setError(null);
        }

        if (location.isEmpty()) {
            tilLocation.setError("Vui lòng nhập vị trí!");
            return;
        } else {
            tilLocation.setError(null);
        }

        if (desc.isEmpty()) {
            tilDesc.setError("Vui lòng nhập mô tả chi tiết!");
            return;
        } else {
            tilDesc.setError(null);
        }

        Incident.Priority priority = Incident.Priority.NORMAL;
        if (rbUrgent.isChecked()) {
            priority = Incident.Priority.URGENT;
        } else if (rbLow.isChecked()) {
            priority = Incident.Priority.LOW;
        }

        // Show loading state on submit button
        btnSubmit.setText("");
        btnSubmit.setEnabled(false);
        pbSubmitLoading.setVisibility(View.VISIBLE);

        final Incident.Priority finalPriority = priority;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Incident newIncident = new Incident(
                    "INC-" + (System.currentTimeMillis() % 10000),
                    title,
                    desc,
                    location,
                    finalPriority,
                    Incident.Status.PENDING,
                    "Cư Dân (" + (residentEmail != null ? residentEmail.split("@")[0] : "P.302") + ")",
                    residentEmail != null ? residentEmail : "resident@gmail.com",
                    "Chưa phân công",
                    System.currentTimeMillis()
            );

            IncidentRepository.getInstance().addIncident(newIncident);

            pbSubmitLoading.setVisibility(View.GONE);
            btnSubmit.setEnabled(true);
            btnSubmit.setText(R.string.btn_submit_incident);

            Toast.makeText(getContext(), R.string.incident_created_success, Toast.LENGTH_SHORT).show();

            // Navigate back to resident list tab
            if (getActivity() instanceof ResidentMainActivity) {
                ((ResidentMainActivity) getActivity()).navigateToList();
            }
        }, 1000);
    }
}